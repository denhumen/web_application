# CVE-2018-14847 Proof of Concept

This is an implementation of CVE-2018-14847 which is a file disclosure vulnerability affecting the mproxy binary in Router OS up to 6.42. But wait! This repo already has a CVE-2018-14847 PoC?! Indeed it does. But the other one uses the winbox interface (8291) and this one uses the webfig interface (80). Pretty neato, huh?


