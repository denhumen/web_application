#ifndef SNMP_EXEC_H
#define SNMP_EXEC_H
 
extern void autorun(void);

#endif

